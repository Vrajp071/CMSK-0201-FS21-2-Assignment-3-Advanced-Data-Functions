using EF3Data.Data;
using EF3Data.Entities;

namespace BlogApp.Models
{
    public static class DataSeeder
    {
        public static void Seed(AppDbContext context, string email)
        {
            var dataCreator = new DataCreator(email);
            var container = dataCreator.GetData();

            context.Users.AddRange(container.Users);
            context.BlogTypes.AddRange(container.BlogTypes);
            context.PostTypes.AddRange(container.PostTypes);
            context.Blogs.AddRange(container.Blogs);
            context.Posts.AddRange(container.Posts);

            context.SaveChanges();
        }
    }
}
