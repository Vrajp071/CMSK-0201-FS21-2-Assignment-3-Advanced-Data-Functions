﻿using System;
using System.Linq;
using BlogApp.Models;
using EF3Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace BlogApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var email = "patelv66@mymacewan.ca";

            using (var context = new AppDbContext())
            {
             
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();

                DataSeeder.Seed(context, email);

                var result = context.Users
                    .Where(u => !u.IsDeleted)
                    .OrderBy(u => u.Name)
                    .Select(u => new
                    {
                        UserName = u.Name,
                        UserEmail = u.EmailAddress,
                        Blogs = u.Posts
                            .Where(p => p.Blog.IsPublic && p.Blog.BlogType.Status == Statuses.Active && !p.Blog.IsDeleted)
                            .Select(p => new
                            {
                                BlogUrl = p.Blog.Url,
                                BlogIsPublic = p.Blog.IsPublic,
                                BlogTypeName = p.Blog.BlogType.Name,
                                Posts = p.Blog.Posts
                                    .Where(post => post.PostType.Status == Statuses.Active && !post.IsDeleted)
                                    .Select(post => new
                                    {
                                        PostUserName = post.User.Name,
                                        PostUserEmail = post.User.EmailAddress,
                                        PostTypeName = post.PostType.Name,
                                        TotalPostsByUser = post.User.Posts.Count
                                    })
                            })
                    })
                    .ToList();

                // Output results
                foreach (var user in result)
                {
                    Console.WriteLine($"User: {user.UserName} ({user.UserEmail})");

                    foreach (var blog in user.Blogs)
                    {
                        Console.WriteLine($"  Blog: {blog.BlogUrl}");
                        Console.WriteLine($"    IsPublic: {blog.BlogIsPublic}");
                        Console.WriteLine($"    Type: {blog.BlogTypeName}");

                        foreach (var post in blog.Posts)
                        {
                            Console.WriteLine($"      Post by: {post.PostUserName} ({post.PostUserEmail})");
                            Console.WriteLine($"        Type: {post.PostTypeName}");
                            Console.WriteLine($"        Total Posts by User: {post.TotalPostsByUser}");
                        }
                    }
                }
            }
        }
    }
}
